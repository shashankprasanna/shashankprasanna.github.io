
**Intel Technical Interview Task – Multimodal Chatbot (Markdown Version)**  

---

### 1. Overview  
Design and implement a simple local UI application that functions as a multimodal chatbot. The app must support both **text input** and **image input**, allowing the user to converse with the bot about an uploaded image or general topics.

---

### 2. Functional Requirements  

| Requirement | Details |
|-------------|---------|
| **Inputs** | • Text input (chat‑style) <br>• Image upload input |
| **Supported image formats** | • JPEG (`.jpg`, `.jpeg`) <br>• PNG (`.png`) |
| **Chat behavior** | • User can ask questions related to the uploaded image.<br>• User can also chat without providing an image. |
| **User Experience** | • Clean, simple, and responsive UI.<br>• Low interaction latency for a conversational feel (no long blocking waits).<br>• Streaming or incremental responses are preferred if feasible. |

---

### 3. Deployment & Environment Constraints  

- Must run entirely on a **local Linux machine**.  
- No internet access at runtime.  
- Do **not assume a discrete GPU**; solution must run acceptably on **CPU‑only systems** (e.g., laptops).  

---

### 4. Model Requirements  

#### 4.1 Model Selection  
Select an appropriate multimodal model (text + image) and justify the choice with respect to:

- **CPU feasibility**
- **Memory footprint**
- **Latency**
- **Output quality**

Quantization and optimization techniques are allowed.

#### 4.2 Deliverables  

- Repository containing the full project.  
- Rationale for model selection.  
- Description of the UI and usage instructions.  

