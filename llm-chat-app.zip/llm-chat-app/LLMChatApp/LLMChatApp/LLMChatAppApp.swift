//
//  LLMChatAppApp.swift
//  LLMChatApp
//
//  Created by Shashank Prasanna on 2/20/26.
//

import SwiftUI

@main
struct LLMChatAppApp: App {
    var body: some Scene {
        WindowGroup {
            ChatView().preferredColorScheme(.light)
        }
    }
}
