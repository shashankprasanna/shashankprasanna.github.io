import SwiftUI
import PhotosUI
import OpenAI
import Combine

struct ChatView: View {
    @StateObject private var viewModel = ChatViewModel()
    @State private var isShowingCamera = false
    @State private var selectedPhotoItem: PhotosPickerItem?

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 12) {
                            ForEach(viewModel.messages) { message in
                                MessageBubble(message: message)
                                    .id(message.id)
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                    }
                    .background(Color(.systemGroupedBackground))
                    .onAppear {
                        if let lastId = viewModel.messages.last?.id {
                            proxy.scrollTo(lastId, anchor: .bottom)
                        }
                    }
                    .onReceive(viewModel.$messages) { messages in
                        if let lastId = messages.last?.id {
                            DispatchQueue.main.async {
                                withAnimation(.easeOut(duration: 0.2)) {
                                    proxy.scrollTo(lastId, anchor: .bottom)
                                }
                            }
                        }
                    }
                }

                Divider()

                InputBar(
                    text: $viewModel.inputText,
                    selectedImage: $viewModel.selectedImage,
                    selectedPhotoItem: $selectedPhotoItem,
                    selectedImageQuality: $viewModel.selectedImageQuality,
                    isStreaming: viewModel.isStreaming,
                    onSend: { Task { await viewModel.sendMessage() } },
                    onCamera: { isShowingCamera = true }
                )
                .onChange(of: selectedPhotoItem) { _, newItem in
                    guard let newItem else { return }
                    Task {
                        if let data = try? await newItem.loadTransferable(type: Data.self),
                           let image = UIImage(data: data) {
                            await MainActor.run {
                                viewModel.selectedImage = image
                                selectedPhotoItem = nil
                            }
                        }
                    }
                }
                .sheet(isPresented: $isShowingCamera) {
                    CameraPicker(image: $viewModel.selectedImage)
                        .ignoresSafeArea()
                }
            }
            .toolbar {
                ToolbarItem(placement: .principal) {
                    VStack(spacing: 0) {
                        Text("Qwen2-VL (OVMS)")
                            .font(.title)
                    }.offset(y: 5)
                }
            }
            .navigationBarTitleDisplayMode(.inline) // Ensures the custom title is centered

            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("New Chat") {
                        viewModel.clearChat()
                    }
                }
            }
        }
    }
}

private struct MessageBubble: View {
    let message: ChatMessage

    var body: some View {
        HStack {
            if message.role == .assistant {
                bubble
                Spacer(minLength: 40)
            } else {
                Spacer(minLength: 40)
                bubble
            }
        }
    }

    private var bubble: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let image = message.image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 160, height: 160)
                    .clipped()
                    .cornerRadius(12)
            }

            if message.role == .assistant && message.text.isEmpty {
                ProgressView()
            } else if !message.text.isEmpty {
                Text(message.text)
                    .foregroundColor(message.role == .assistant ? .primary : .white)
                    .font(.body)
            }
        }
        .padding(12)
        .background(message.role == .assistant ? Color(.secondarySystemBackground) : Color(.systemBlue))
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(message.role == .assistant ? Color(.separator) : Color.clear, lineWidth: 1)
        )
    }
}

private struct InputBar: View {
    @Binding var text: String
    @Binding var selectedImage: UIImage?
    @Binding var selectedPhotoItem: PhotosPickerItem?
    @Binding var selectedImageQuality: ImageQualityOption
    let isStreaming: Bool
    let onSend: () -> Void
    let onCamera: () -> Void

    var body: some View {
        VStack(spacing: 8) {
            if let selectedImage {
                HStack(spacing: 8) {
                    Image(uiImage: selectedImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 48, height: 48)
                        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                    Button("Remove") {
                        self.selectedImage = nil
                    }
                    .buttonStyle(.borderless)
                    Spacer()
                }
                .padding(.horizontal, 16)
            }

            HStack(spacing: 8) {
                Button {
                    onCamera()
                } label: {
                    Image(systemName: "camera")
                        .font(.system(size: 18, weight: .semibold))
                }
                .buttonStyle(.borderless)

                PhotosPicker(selection: $selectedPhotoItem, matching: .images, photoLibrary: .shared()) {
                    Image(systemName: "photo")
                        .font(.system(size: 18, weight: .semibold))
                }

                Menu {
                    ForEach(ImageQualityOption.allCases) { quality in
                        Button(quality.label) {
                            selectedImageQuality = quality
                        }
                    }
                } label: {
                    Text(selectedImageQuality.shortLabel)
                        .font(.caption.weight(.semibold))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 6)
                        .background(Color(.secondarySystemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                }
                .buttonStyle(.plain)

                TextField("Message", text: $text, axis: .vertical)
                    .submitLabel(.send)
                    .onSubmit(onSend)
                    .lineLimit(1...5)
                    .textFieldStyle(.plain)
                    .padding(10)
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))

                Button {
                    onSend()
                } label: {
                    Image(systemName: "paperplane.fill")
                        .font(.system(size: 18, weight: .semibold))
                }
                .disabled(isStreaming || (text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && selectedImage == nil))
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
        }
        .background(.ultraThinMaterial)
    }
}

enum ImageQualityOption: String, CaseIterable, Identifiable {
    case small = "Small (336px)"
    case medium = "Medium (448px)"
    case large = "Large (672px)"

    var id: String { rawValue }

    var maxDimension: CGFloat {
        switch self {
        case .small: return 336
        case .medium: return 448
        case .large: return 672
        }
    }

    var label: String { rawValue }

    var shortLabel: String {
        "\(Int(maxDimension))px"
    }
}


@MainActor
final class ChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var inputText: String = ""
    @Published var selectedImage: UIImage?
    @Published var selectedImageQuality: ImageQualityOption = .small
    @Published var isStreaming: Bool = false

    private let modelName = "Qwen/Qwen2-VL-2B-Instruct"
    private let client = OpenAI(
        configuration: .init(
            token: nil,
            host: "localhost",
            port: 8000,
            scheme: "http",
            basePath: "/v3",
            parsingOptions: .relaxed
        )
    )

    func clearChat() {
        messages.removeAll()
        inputText = ""
        selectedImage = nil
    }

    func sendMessage() async {
        let trimmedText = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedText.isEmpty || selectedImage != nil else { return }

        let imageData = selectedImage?.preprocessedJPEG(maxDimension: selectedImageQuality.maxDimension, compressionQuality: 0.7)
        let userMessage = ChatMessage(role: .user, text: trimmedText, image: selectedImage, cachedImageData: imageData)
        messages.append(userMessage)
        inputText = ""
        selectedImage = nil

        let assistantMessage = ChatMessage(role: .assistant, text: "")
        messages.append(assistantMessage)
        let assistantIndex = messages.count - 1

        isStreaming = true
        do {
            try await fetchResponse(intoMessageAt: assistantIndex)
        } catch {
            messages[assistantIndex].text = "Error: \(error.localizedDescription)"
        }
        isStreaming = false
    }

    private func fetchResponse(intoMessageAt index: Int) async throws {
        let query = buildQuery()
        let stream: AsyncThrowingStream<ChatStreamResult, Error> = client.chatsStream(query: query)
        for try await result in stream {
            if let delta = result.choices.first?.delta.content {
                messages[index].text += delta
            }
        }
        let trimmed = messages[index].text.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            messages[index].text = "(empty response)"
        }
    }

    private func buildQuery() -> ChatQuery {
        var payloadMessages: [ChatQuery.ChatCompletionMessageParam] = []
        for message in messages.suffix(20) {
            guard let content = message.chatMessageParam() else { continue }
            payloadMessages.append(content)
        }
        return ChatQuery(messages: payloadMessages, model: modelName, stream: true)
    }
}

struct ChatMessage: Identifiable, Equatable {
    let id: UUID
    let role: MessageRole
    var text: String
    var image: UIImage?
    var cachedImageData: Data?

    init(role: MessageRole, text: String, image: UIImage? = nil, cachedImageData: Data? = nil) {
        self.id = UUID()
        self.role = role
        self.text = text
        self.image = image
        self.cachedImageData = cachedImageData
    }

    func chatMessageParam() -> ChatQuery.ChatCompletionMessageParam? {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        switch role {
        case .user:
            if image != nil, let resizedData = cachedImageData {
                var parts: [ChatQuery.ChatCompletionMessageParam.UserMessageParam.Content.ContentPart] = []
                if !trimmed.isEmpty {
                    parts.append(.text(.init(text: trimmed)))
                }
                parts.append(
                    .image(
                        .init(
                            imageUrl: .init(
                                imageData: resizedData,
                                detail: .auto
                            )
                        )
                    )
                )
                return .user(.init(content: .contentParts(parts)))
            }
            guard !trimmed.isEmpty else { return nil }
            return .user(.init(content: .string(trimmed)))
        case .assistant:
            guard !trimmed.isEmpty else { return nil }
            return .assistant(.init(content: .textContent(trimmed)))
        }
    }
}

enum MessageRole {
    case user
    case assistant
}

extension UIImage {
    func preprocessedJPEG(maxDimension: CGFloat, compressionQuality: CGFloat) -> Data? {
        let maxSide = max(size.width, size.height)
        guard maxSide > 0 else { return nil }

        let scale = min(1, maxDimension / maxSide)
        let targetWidth = max(28, (Int(size.width * scale) / 28) * 28)
        let targetHeight = max(28, (Int(size.height * scale) / 28) * 28)
        let newSize = CGSize(width: targetWidth, height: targetHeight)

        let format = UIGraphicsImageRendererFormat.default()
        format.scale = 1
        let renderer = UIGraphicsImageRenderer(size: newSize, format: format)
        let resized = renderer.image { _ in
            draw(in: CGRect(origin: .zero, size: newSize))
        }
        return resized.jpegData(compressionQuality: compressionQuality)
    }
}

struct CameraPicker: UIViewControllerRepresentable {
    @Environment(\.dismiss) private var dismiss
    @Binding var image: UIImage?

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = .camera
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    final class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        private let parent: CameraPicker

        init(_ parent: CameraPicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.originalImage] as? UIImage {
                parent.image = image
            }
            parent.dismiss()
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.dismiss()
        }
    }
}
