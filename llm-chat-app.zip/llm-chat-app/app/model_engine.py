import queue
import threading
from collections.abc import Iterator
from pathlib import Path

import numpy as np
import openvino as ov
import openvino_genai as ov_genai
from PIL import Image

DEFAULT_MODEL_DIR = Path(__file__).parent.parent / "models" / "qwen2-vl-2b-instruct-int4"
DEFAULT_MAX_NEW_TOKENS = 512
MAX_IMAGE_DIM = 672 #28*24

def _preprocess_image(image, max_dim=MAX_IMAGE_DIM) -> Image.Image:
    """Resize image so longest side <= max_dim, dimensions rounded to 28px."""
    image = image.convert("RGB")
    w, h = image.size
    scale = max_dim / max(w, h)
    new_w = max(28, (int(w * scale) // 28) * 28)
    new_h = max(28, (int(h * scale) // 28) * 28)
    return image.resize((new_w, new_h), Image.LANCZOS)

def _pil_to_ov_tensor(image, max_dim=MAX_IMAGE_DIM) -> ov.Tensor:
    """Convert a PIL Image to an OpenVINO Tensor (with preprocessing)."""
    return ov.Tensor(np.array(_preprocess_image(image, max_dim=max_dim)))

def load_model(model_dir=None, device="CPU", **kwargs) -> ov_genai.VLMPipeline:
    """Load a VLMPipeline from *model_dir*."""
    model_dir = Path(model_dir) if model_dir else DEFAULT_MODEL_DIR
    if not model_dir.exists():
        raise FileNotFoundError(
            f"Model directory not found: {model_dir}\n"
            "Run notebooks/model_preparation.ipynb first."
        )
    config = {"PERFORMANCE_HINT": "LATENCY", **kwargs}
    return ov_genai.VLMPipeline(str(model_dir), device, **config)

def new_history(messages=None) -> ov_genai.ChatHistory:
    """Create a ChatHistory"""
    history = ov_genai.ChatHistory()
    if messages:
        for msg in messages:
            history.append(msg)
    return history

class OpenVINOStreamer:
    """Streams tokens from a VLMPipeline; exposes .metrics after iteration."""

    def __init__(self, pipe: ov_genai.VLMPipeline):
        self.pipe = pipe
        self.metrics: ov_genai.PerfMetrics | None = None

    def stream(self, history, prompt, image=None,
               max_new_tokens=DEFAULT_MAX_NEW_TOKENS,
               temperature=0.0, top_p=1.0, top_k=50,
               max_dim=MAX_IMAGE_DIM) -> Iterator[str]:
        """Stream a response token-by-token.

        Appends a user message before generation and an assistant message after.
        """
        self.metrics = None

        history.append({"role": "user", "content": prompt})

        config = ov_genai.GenerationConfig()
        config.max_new_tokens = max_new_tokens
        config.repetition_penalty = 1.1
        if temperature > 0:
            config.do_sample = True
            config.temperature = temperature
            config.top_p = top_p
            config.top_k = top_k
        else:
            config.do_sample = False

        token_queue = queue.Queue()
        response_parts = []
        error_holder = []

        def streamer_callback(token):
            response_parts.append(token)
            token_queue.put(token)
            return False

        def run():
            try:
                gen_kwargs = {"generation_config": config,
                              "streamer": streamer_callback}
                if image is not None:
                    gen_kwargs["images"] = [_pil_to_ov_tensor(image, max_dim=max_dim)]
                result = self.pipe.generate(history, **gen_kwargs)
                self.metrics = result.perf_metrics
            except Exception as e:
                error_holder.append(e)
            finally:
                token_queue.put(None)

        threading.Thread(target=run, daemon=True).start()

        while True:
            token = token_queue.get()
            if token is None:
                break
            yield token

        history.append({"role": "assistant",
                        "content": "".join(response_parts)})

        if error_holder:
            raise error_holder[0]
