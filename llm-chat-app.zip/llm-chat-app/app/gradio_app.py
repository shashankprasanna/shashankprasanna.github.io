import argparse

import gradio as gr
from PIL import Image

from app.model_engine import DEFAULT_MODEL_DIR, OpenVINOStreamer, load_model, new_history

IMAGE_QUALITY_MAP = {"Small (336px)": 336, "Medium (448px)": 448, "Large (672px)": 672}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-dir", default=str(DEFAULT_MODEL_DIR))
    parser.add_argument("--port", type=int, default=7860)
    args = parser.parse_args()

    print(f"Loading model from {args.model_dir}...")
    streamer = OpenVINOStreamer(load_model(args.model_dir))
    chat_history = new_history()
    print("Model loaded.")

    def respond(message, _history, temperature, max_tokens, top_p, img_quality):
        user_text = message.get("text", "").strip()
        files = message.get("files", [])
        if not user_text and not files:
            yield ""
            return

        image = None
        if files:
            path = files[0] if isinstance(files[0], str) else files[0].get("path", "")
            if path:
                image = Image.open(path)

        prompt = user_text or "Describe this image."

        max_dim = IMAGE_QUALITY_MAP.get(img_quality, 448)
        response = ""

        for token in streamer.stream(
            chat_history, prompt, image=image,
            max_new_tokens=int(max_tokens), temperature=temperature,
            top_p=top_p, max_dim=max_dim,
        ):
            response += token
            yield response

        if streamer.metrics:
            metrics = streamer.metrics
            ttft = metrics.get_ttft().mean
            tok_s = metrics.get_throughput().mean
            n_tok = metrics.get_num_generated_tokens()
            stats = f"\n\n*TTFT: {ttft:.0f}ms · {tok_s:.1f} tok/s · {n_tok} tokens*"
            yield response + stats

    def clear_chat():
        chat_history.clear()

    demo = gr.ChatInterface(
        fn=respond,
        multimodal=True,
        title="Qwen2-VL Chat (OpenVINO)",
        description="Multimodal chatbot powered by Qwen2-VL-2B-Instruct with OpenVINO.",
        chatbot=gr.Chatbot(height=400),
        textbox=gr.MultimodalTextbox(
            file_types=["image"], file_count="single",
            placeholder="Type a message or upload an image...",
        ),
        additional_inputs=[
            gr.Slider(0.0, 2.0, value=0.0, step=0.1, label="Temperature",
                      info="0 = greedy / deterministic"),
            gr.Slider(64, 2048, value=512, step=64, label="Max Tokens"),
            gr.Slider(0.0, 1.0, value=1.0, step=0.05, label="Top-P"),
            gr.Radio(choices=list(IMAGE_QUALITY_MAP.keys()),
                     value="Medium (448px)", label="Image Quality",
                     info="Max resolution sent to model"),
        ],
        additional_inputs_accordion=gr.Accordion("Generation Settings", open=False),
    )
    with demo:
        demo.chatbot.clear(clear_chat)
        demo.launch(server_name="0.0.0.0", server_port=args.port, share=False)

if __name__ == "__main__":
    main()
