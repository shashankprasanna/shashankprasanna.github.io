#!/bin/bash
set -e

if [ "$MODE" = "jupyter" ]; then
    exec jupyter lab \
        --ip=0.0.0.0 --port=8888 \
        --no-browser --allow-root \
        --NotebookApp.token='' \
        --notebook-dir=/app/notebooks
else
    # Start Jupyter in the background for notebook access
    jupyter lab \
        --ip=0.0.0.0 --port=8888 \
        --no-browser --allow-root \
        --NotebookApp.token='' \
        --notebook-dir=/app/notebooks &

    # Start Gradio in the foreground
    exec python -m app.gradio_app "$@"
fi
