# Qwen2-VL Multimodal Chatbot with OpenVINO

A local multimodal chatbot (text + image) that runs on CPU-only Linux machines with no internet required at runtime. Uses **Qwen2-VL-2B-Instruct** with **OpenVINO** for inference, quantized to INT4 for fast CPU performance.

## Model

| Variant | Size on Disk | Notes |
|---------|-------------|-------|
| FP16 | ~4.7 GB | Full precision, used as export base |
| INT8 | ~2.4 GB | Good quality/speed balance |
| INT4 | ~1.8 GB | Fastest inference, recommended for CPU |

### Why Qwen2-VL-2B-Instruct?

**Size & performance**: Qwen2-VL-2B is the smallest vision-language model that delivers strong multimodal quality. At INT4 quantization it fits in under 2 GB of RAM, making it practical for CPU-only inference on commodity hardware.

**Alternatives considered**:

- **LLaVA-1.5-7B** — Older architecture, 7B parameters is too large for responsive CPU inference, and lacks native OpenVINO GenAI ChatHistory support.
- **MiniCPM-V-2.6** — Capable but larger (~3B effective params with vision encoder), slower prefill on CPU.
- **Phi-4-Multimodal (14B)** — Excellent quality but far too large for CPU-only deployment; requires GPU or >16 GB RAM.

**Why INT4 quantization**: The INT4 variant is 2.6x smaller than FP16 with minimal quality degradation. On Intel CPUs, OpenVINO's INT4 kernels deliver the fastest inference throughput.

**Why OpenVINO**: Intel's inference runtime, purpose-built for Intel CPUs. Provides native INT4/INT8 quantization support, optimized CPU kernels, and the GenAI API with built-in chat history and streaming.

## Project Structure

```
llm-chat-app/
├── README.md
├── pyproject.toml                  # Project dependencies (managed by uv)
├── uv.lock                         # Locked dependency versions
├── app/
│   ├── __init__.py
│   ├── model_engine.py             # OpenVINO VLMPipeline + ChatHistory engine
│   └── gradio_app.py               # Gradio multimodal chat UI
├── notebooks/
│   ├── model_preparation.ipynb     # Download, export, quantize, smoke test
│   └── gradio_demo.ipynb           # Interactive Gradio demo in notebook
├── LLMChatApp/                     # Native iOS client (connects to OVMS API)
├── Dockerfile                      # Distributable Gradio + Jupyter image
├── entrypoint.sh                   # Selects gradio vs jupyter mode
├── docker-compose.yml              # OVMS + Open WebUI + app
├── export_ovms_model.sh            # One-time OVMS model export helper
└── models/                         # Created by notebook (gitignored)
    ├── qwen2-vl-2b-instruct-fp16/
    ├── qwen2-vl-2b-instruct-int8/
    └── qwen2-vl-2b-instruct-int4/
```

## Quick Start

### Prerequisites

- Python 3.12+
- [uv](https://docs.astral.sh/uv/) package manager
- Linux (tested on Ubuntu)
- At least 4 GB RAM
- Internet connection (for initial model download only)

### 1. Set Up Environment

```bash
uv sync
source .venv/bin/activate
```

### 2. Download & Prepare Models

```bash
jupyter lab notebooks/model_preparation.ipynb
```

This will download Qwen2-VL-2B-Instruct from Hugging Face, export to OpenVINO IR (FP16), and create INT8 and INT4 quantized variants.

### 3. Launch the Chat UI

```bash
python -m app.gradio_app
# or using the entry point:
uv run llm-chat
```

Opens at http://localhost:7860.

```bash
# Use a specific model variant
python -m app.gradio_app --model-dir models/qwen2-vl-2b-instruct-int8
```

**UI Features:**

- **Multimodal input** — type text, upload an image (JPEG/PNG), or both
- **Streaming responses** — tokens appear incrementally as they are generated
- **Generation settings** — adjustable Temperature, Max Tokens, Top-P, and Image Quality (collapsed under an accordion)
- **Performance metrics** — each response shows TTFT (time to first token), tokens/sec throughput, and total token count
- **Chat history** — conversation persists across turns; clear with the built-in button

### Interactive Notebook Demo

Run the Gradio chatbot inline in Jupyter:

```bash
jupyter lab notebooks/gradio_demo.ipynb
```

## Docker Deployment

The Docker setup uses three services:

| Service | Description | Port |
|---------|-------------|------|
| `model-server` | OpenVINO Model Server (OVMS) — serves the model via OpenAI-compatible API | 8000 |
| `open-webui` | Open WebUI — chat frontend | 3000 |
| `app` | Gradio app (or Jupyter) | 7860 / 8888 |

The `LLMChatApp/` directory contains a native iOS client that can also connect to the OVMS API as an alternative frontend.

### Export Model for OVMS (one-time setup)

Before starting Docker, export the model into the format OVMS expects. This requires internet access and only needs to be done once:

```bash
bash export_ovms_model.sh
```

This clones the OVMS helper scripts, exports Qwen2-VL-2B-Instruct at INT4, and places the result in `models-ovms/`.

### Build & Run

```bash
docker compose up --build
```

Subsequent runs are fully offline using the cached `models-ovms/` volume.

### Run in Jupyter Mode

```bash
MODE=jupyter docker compose up app
```

### API Endpoints (OVMS)

OVMS exposes an OpenAI-compatible API at `http://localhost:8000`:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/v3/chat/completions` | POST | Chat completion (streaming & non-streaming) |
| `/v1/config` | GET | Server configuration |

### Test with curl

```bash
# Text chat
curl -X POST http://localhost:8000/v3/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen2-vl-2b-instruct",
    "messages": [{"role": "user", "content": "What is OpenVINO?"}],
    "max_tokens": 200
  }'

# Image chat (base64-encoded image)
curl -X POST http://localhost:8000/v3/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen2-vl-2b-instruct",
    "messages": [{
      "role": "user",
      "content": [
        {"type": "text", "text": "What do you see?"},
        {"type": "image_url", "image_url": {"url": "data:image/png;base64,..."}}
      ]
    }],
    "max_tokens": 200
  }'
```

## Performance Notes

- **Image preprocessing**: Input images are resized so the longest side is at most 672px. Qwen2-VL tiles images into 28x28 patches — capping the size dramatically reduces prefill time on CPU.
- **Device hints**: `PERFORMANCE_HINT=LATENCY` is passed to VLMPipeline for optimized single-request inference.
- **Greedy decoding**: `do_sample=False` for faster, deterministic generation.

## Offline Usage

After running the model preparation notebook once (requires internet), all runtime inference is fully offline:
- Models are loaded from the local `models/` directory
- No API calls or internet access needed
- Suitable for air-gapped environments
