# Clone the repository to access the helper script export_model.py
git clone https://github.com/openvinotoolkit/model_server

# Create ovms model directory
mkdir -p models-ovms

# Run helper script with a temporary isolated python env
uv run --isolated --no-project --python 3.12 \
    --pre \
    --extra-index-url https://download.pytorch.org/whl/cpu \
    --with-requirements model_server/demos/common/export_models/requirements.txt \
    model_server/demos/common/export_models/export_model.py text_generation \
    --source_model Qwen/Qwen2-VL-2B-Instruct \
    --weight-format int4 \
    --config_file_path models-ovms/config_all.json \
    --model_repository_path models-ovms

# Change ownership of the model directory to container user UID 5000
sudo chown -R 5000:5000 models-ovms

# Delete the repository we cloned for the helper script export_model.py
rm -rf model_server