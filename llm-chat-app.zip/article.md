---
title: "Building a local multimodal Chatbot with OpenVINO"
description: >
 Guide to building and deploying a CPU-only local multimodal chatbot, accessible through: <br> **(1) Gradio chat UI, (2) Jupyter notebook, (3) Open WebUI and (4) iOS app.**
type: "blog"
weight: 700
url: vlm_openvino
draft: false
tags: 
---

[image: hero collage — Gradio chat UI, Jupyter notebook, Open WebUI, and iOS app side-by-side]

[image: Gradio chat UI with an uploaded image and streaming response]
[image: Jupyter notebook running the Gradio demo inline]
[image: Open WebUI connected to OVMS]
[image: iOS app showing a multimodal conversation]

This guide walks through building a multimodal chatbot that supports text and image input, streaming responses, and runs entirely on a local CPU with no internet access at runtime. Here's what we'll build: 

1. A **model preparation pipeline** — download, export, and quantize a vision-language model for CPU inference
2. An **inference engine** with streaming — image preprocessing, chat history, and token-by-token output
3. A **Gradio web UI** and **Jupyter notebook** for local experimentation
4. A **Docker Compose stack** with OVMS (OpenVINO Model Server) serving the model over an OpenAI-compatible API
5. Two production-ready clients 
   * **Open WebUI** (zero-code ChatGPT-like frontend) and 
   * **Native iOS app** built with SwiftUI

I'll share the architectural decisions, trade-offs, and rough edges along the way. I've also included a friction log at the end based on my experience building this project.

## Running the project

#### Option 1: Local (Gradio or Jupyter)

Install dependencies with `uv`, then launch the Gradio app or the notebook:

```bash
uv sync
source .venv/bin/activate

# Launch the Gradio chat UI at http://localhost:7860
python -m app.gradio_app

# Or open the interactive notebook
jupyter lab notebooks/gradio_demo.ipynb

```

This requires running the model preparation notebook first (`notebooks/model_preparation.ipynb`) to download and quantize the model.

#### Option 2: Docker Compose (OVMS + all clients)

To skip the local Python setup entirely:

```bash
# One-time: export the model for OVMS (requires internet)
bash export_ovms_model.sh

# Start all services
docker compose up --build

```

#### Option 3: iOS client

Open `LLMChatApp/LLMChatApp.xcodeproj` in Xcode, build and run in the simulator. The app connects to OVMS at `localhost:8000`, so the Docker stack needs to be running.


## Project overview

This project has three components (1) Local development environment (2) Docker based deployment stack and (3) Open WebUI and iOS clients.

#### 1. Local setup for development and testing environment
This includes Python files and Jupyter notebook for model preparation and chatbot UI using Gradio. You can use `uv` and the accompanying `pyproject.toml` to quickly setup your development environment. Alternatively, I've also provided a `Dockerfile` with all the dependencies and Jupyter notebooks included if you don't want to do a local environment setup.

#### 2. Docker Compose stack for a more portable setup and reproducibility
This includes `docker-compose.yml` file with specifications for:
1. Containerized local development environment that gives you the same environment discussed above.
2. OVMS (OpenVINO Model Server) hosting the models generated from step (1), making it accessible to clients like Open WebUI and iOS apps.

#### 3. Chatbot clients used in production
This includes two clients:
1. Open WebUI client service that can be started from the same Docker Compose stack as above. It auto-discovers OVMS service and our hosted models.
2. A full-fledged iOS chat app that accesses OVMS over the network to deliver a multimodal chat experience, allowing users to upload their photos or take camera photos and share it in the chatbot.

The complete project structure is as follows:

```
llm-chat-app/
├── app/
│   ├── __init__.py
│   ├── model_engine.py             # OpenVINO VLMPipeline + streaming engine
│   └── gradio_app.py               # Gradio multimodal chat UI
├── notebooks/
│   ├── model_preparation.ipynb     # Download, export, quantize, test
│   └── gradio_demo.ipynb           # Interactive Gradio demo in Jupyter
├── LLMChatApp/                     # Native iOS client (SwiftUI + OpenAI SDK)
│   └── LLMChatApp/
│       ├── LLMChatAppApp.swift
│       └── ChatView.swift
├── Dockerfile                      # Distributable Gradio + Jupyter image
├── entrypoint.sh                   # Launches gradio and jupyter servers
├── docker-compose.yml              # OVMS + Open WebUI + Gradio app
├── export_ovms_model.sh            # One-time OVMS model export
├── pyproject.toml                  # Dependencies (managed by uv)
└── models/                         # Created by notebook (gitignored)
    ├── qwen2-vl-2b-instruct-fp16/  # Created by notebook (gitignored)
    └── qwen2-vl-2b-instruct-int4/  # Created by notebook (gitignored)

```


Now, let's walk through building this project. I'll share architectural considerations and choices along the way.

## Choosing the right model

There are a lot of VLM models on HuggingFace to choose from, but our first step is to check what models are actually supported by OpenVINO GenAI's `VLMPipeline`. `VLMPipeline` is the high-level API for VLM inference — it handles chat history, image input, streaming, and generation config. But it only works with specific architectures or similar, listed on the [OpenVINO GenAI docs](https://docs.openvino.ai/2025/learn-openvino/llm_inference_guide/genai-guide-vlm.html). 

This ruled out my first choice which was HuggingFace's `SmolVLM-256M` and `SmolVLM-500M` as these are not supported with `VLMPipeline`. On further research, I found out that you can run these using `OVModelForCausalLM` API but it comes with some downsides, namely the entire bulk of HuggingFace transformers is now part of your deployment package. Therefore this was not really an option.

From the list of models supported by `VLMPipeline`, I narrowed down to these.

| Model | Parameters | Why we passed |
| --- | --- | --- |
| LLaVA-1.5 | 7B | Too large. Older. |
| MiniCPM-V-2.6 | ~3B | Slower prefill. |
| Phi-4-Multimodal | 14B | Too large. |
| **Qwen2-VL-2B-Instruct** | **2B** | **Sweet spot, with native `VLMPipeline` support.** |

Qwen2-VL-2B-Instruct is the smallest vision-language model in the supported list that delivers usable quality. At INT4, it fits under 2 GB on disk.

## Model preparation

We're now ready to prepare the model for deployment with OpenVINO. The code excerpts discussed below live in our Jupyter notebook (`notebooks/model_preparation.ipynb`).

First we use `optimum-cli` to download the model from HuggingFace and export it as half-precision model represented in OpenVINO IR:

```bash
optimum-cli export openvino \
    --model Qwen/Qwen2-VL-2B-Instruct \
    --task image-text-to-text \
    --weight-format fp16 \
    --trust-remote-code \
    models/qwen2-vl-2b-instruct-fp16

```

### Quantize to INT4
To get this running fast on a CPU, we have to further quantize it. For INT4, we use symmetric quantization with group size 64:

```bash
optimum-cli export openvino \
    --model Qwen/Qwen2-VL-2B-Instruct \
    --task image-text-to-text \
    --weight-format int4 \
    --group-size 64 \
    --sym \
    --trust-remote-code \
    models/qwen2-vl-2b-instruct-int4
```

#### Size comparison

| Variant | Size | Compression vs FP16 |
| --- | --- | --- |
| FP16 | 4,685 MB | Baseline |
| INT4 | 1,773 MB | 2.6x smaller |

### Testing inference

Before building any UI, we verify the model loads and generates output:

```python
import openvino_genai as ov_genai

pipe = ov_genai.VLMPipeline(str(INT4_DIR), "CPU")

config = ov_genai.GenerationConfig()
config.max_new_tokens = 100

history = ov_genai.ChatHistory()
history.append({"role": "user", "content": "What is the capital of France?"})

result = pipe.generate(history, generation_config=config)
print(result.texts[0])
```

Output
```
The capital of France is Paris.
```

## Model inference engine
With the model quantized, we can now implement additional components we need to serve the model. The inference engine lives in `app/model_engine.py`. It handles image preprocessing, model loading, and token streaming.

### Image preprocessing for performance

Even with INT4 quantization, I found that the prefill step was taking several seconds to run, making the chat experience unsatisfying. The issue wasn't the text but the image input tokenization. Unfortunately, CPUs are not the best brute-force throughput engines to crunch through image processing. So, I did the next best thing, reduce the size of the image before sending it to the model. Later you'll see that I've implemented the same technique for SwiftUI iOS app and Open WebUI on the client side.

Qwen2-VL tiles images into 28x28 pixel patches. This means a large photo produces a large number of patches, and the prefill time grows accordingly. What we can do is scale down the image but keep it as a multiple of 28 so there are no partial patches. This ensures that the image tokenization can be speedy.

Later you'll see that we predefine small, medium and large sizes in `app/gradio_app.py`, used in both the Gradio UI and mirrored as an `ImageQualityOption` enum in the iOS app:

```python
IMAGE_QUALITY_MAP = {"Small (336px)": 336, "Medium (448px)": 448, "Large (672px)": 672}
```
On the Python side of things, this is our simple preprocessor:
```python
MAX_IMAGE_DIM = 672  # 28*24

def _preprocess_image(image, max_dim=MAX_IMAGE_DIM) -> Image.Image:
    """Resize image so longest side <= max_dim, dimensions rounded to 28px."""
    image = image.convert("RGB")
    w, h = image.size
    scale = max_dim / max(w, h)
    new_w = max(28, (int(w * scale) // 28) * 28)
    new_h = max(28, (int(h * scale) // 28) * 28)
    return image.resize((new_w, new_h), Image.LANCZOS)

```
Here `max(28, ...)` prevents zero-dimension images. `// 28 * 28` rounds down to the nearest multiple of 28. We implement [similar preprocessor in Swift](#client-side-image-preprocessing) for the iOS app.

To pass a preprocessed image into `VLMPipeline`, we convert it to an OpenVINO tensor:

```python
def _pil_to_ov_tensor(image, max_dim=MAX_IMAGE_DIM) -> ov.Tensor:
    return ov.Tensor(np.array(_preprocess_image(image, max_dim=max_dim)))
```

### Loading the model

`load_model()` wraps `VLMPipeline` with `PERFORMANCE_HINT=LATENCY`, which tells OpenVINO to optimize for single-request latency rather than throughput. Simplified excerpt below (see `app/model_engine.py` for the full implementation):

```python
def load_model(model_dir=None, device="CPU", **kwargs) -> ov_genai.VLMPipeline:
    model_dir = Path(model_dir) if model_dir else DEFAULT_MODEL_DIR
    config = {"PERFORMANCE_HINT": "LATENCY", **kwargs}
    return ov_genai.VLMPipeline(str(model_dir), device, **config)

```

### Chat history

The [OpenVINO GenAI documentation](https://openvinotoolkit.github.io/openvino.genai/docs/guides/chat-scenario) recommends using the newer `ChatHistory` object shared between the caller and the model. This new API replaces the older `start_chat()` / `finish_chat()` APIs. The `new_history()` helper in `model_engine.py` creates a `ChatHistory` and optionally seeds it with messages:

```python
def new_history(messages=None) -> ov_genai.ChatHistory:
    history = ov_genai.ChatHistory()
    if messages:
        for msg in messages:
            history.append(msg)
    return history
```

The caller owns the history object and passes it into every `stream()` call — the engine appends user and assistant messages as it generates.

> **Important version note:** After a lot of trial and error, I discovered that `ChatHistory` is *only* supported for `LLMPipeline` and support for `VLMPipeline` is only available on the pre-release builds. Therefore I had to specifically pin the environment to the pre-release to make multi-turn conversations work with `ChatHistory`.

### Streaming with Thread + Queue

The current implementation of `VLMPipeline.generate()` is a blocking call. To stream tokens to the UI as they're produced, we can run the generation on a background thread using `threading.Thread` and use `queue.Queue` to pass tokens to the main thread, which yields them as a Python generator.

Here's our `OpenVINOStreamer` class:

```python
class OpenVINOStreamer:
    """Streams tokens from a VLMPipeline; exposes .metrics after iteration."""

    def __init__(self, pipe: ov_genai.VLMPipeline):
        self.pipe = pipe
        self.metrics: ov_genai.PerfMetrics | None = None

    def stream(self, history, prompt, image=None,
               max_new_tokens=DEFAULT_MAX_NEW_TOKENS,
               temperature=0.0, top_p=1.0, top_k=50,
               max_dim=MAX_IMAGE_DIM) -> Iterator[str]:
        """Stream a response token-by-token.

        Appends a user message before generation and an assistant message after.
        """
        self.metrics = None

        history.append({"role": "user", "content": prompt})

        config = ov_genai.GenerationConfig()
        config.max_new_tokens = max_new_tokens
        config.repetition_penalty = 1.1
        if temperature > 0:
            config.do_sample = True
            config.temperature = temperature
            config.top_p = top_p
            config.top_k = top_k
        else:
            config.do_sample = False

        token_queue = queue.Queue()
        response_parts = []
        error_holder = []

        def streamer_callback(token):
            response_parts.append(token)
            token_queue.put(token)
            return False

        def run():
            try:
                gen_kwargs = {"generation_config": config,
                              "streamer": streamer_callback}
                if image is not None:
                    gen_kwargs["images"] = [_pil_to_ov_tensor(image, max_dim=max_dim)]
                result = self.pipe.generate(history, **gen_kwargs)
                self.metrics = result.perf_metrics
            except Exception as e:
                error_holder.append(e)
            finally:
                token_queue.put(None)

        threading.Thread(target=run, daemon=True).start()

        while True:
            token = token_queue.get()
            if token is None:
                break
            yield token

        history.append({"role": "assistant",
                        "content": "".join(response_parts)})

        if error_holder:
            raise error_holder[0]

```

The key ideas:

* VLMPipeline calls `streamer_callback` function with each generated token. The callback puts the token into the queue and returns `False` to continue generation.
* The `finally` block pushes `None` into the queue after generation completes or fails. The main thread breaks on `None`.

## Implementing the Gradio UI
In this section we'll implement Gradio UI:
1. Embedded within a Jupyter notebook and
2. As a stand-alone app 

### Gradio UI embedded in Jupyter notebook

The notebook `notebooks/gradio_demo.ipynb` reuses the same `model_engine.py` module we built above — no code duplication. It's a three-cell workflow:

1. **Setup** — add the project root to `sys.path` and set the model directory.
2. **Load** — import `load_model`, `new_history`, and `OpenVINOStreamer` from `app.model_engine`, then instantiate the streamer.
3. **Launch** — build a `gr.ChatInterface` and call `demo.launch(inline=True, share=False)` to embed the chat UI right inside the notebook output cell.


```python
chat_history = new_history()

def respond(message, _history):
    user_text = message.get("text", "").strip()
    files = message.get("files", [])
    if not user_text and not files:
        yield ""
        return

    image = None
    if files:
        path = files[0] if isinstance(files[0], str) else files[0].get("path", "")
        if path:
            image = Image.open(path)

    prompt = user_text or "Describe this image."
    response = ""

    for token in streamer.stream(chat_history, prompt, image=image):
        response += token
        yield response

demo = gr.ChatInterface(
    fn=respond,
    multimodal=True,
    title="Qwen2-VL Chat (OpenVINO)",
    textbox=gr.MultimodalTextbox(
        file_types=["image"], file_count="single",
        placeholder="Type a message or upload an image...",
    ),
)
demo.launch(inline=True, share=False)
```

### Gradio web UI with a stand-alone app
The UI in `app/gradio_app.py` uses Gradio's `ChatInterface` for layout. We define a `respond()` function which is a generator that yields the concatenated response string on each token. Gradio streams this to the chat bubble in real time:

```python
def respond(message, _history, temperature, max_tokens, top_p, img_quality):
    user_text = message.get("text", "").strip()
    files = message.get("files", [])
    if not user_text and not files:
        yield ""
        return

    image = None
    if files:
        path = files[0] if isinstance(files[0], str) else files[0].get("path", "")
        if path:
            image = Image.open(path)

    prompt = user_text or "Describe this image."
    max_dim = IMAGE_QUALITY_MAP.get(img_quality, 448)
    response = ""

    for token in streamer.stream(
        chat_history, prompt, image=image,
        max_new_tokens=int(max_tokens), temperature=temperature,
        top_p=top_p, max_dim=max_dim,
    ):
        response += token
        yield response

    if streamer.metrics:
        metrics = streamer.metrics
        ttft = metrics.get_ttft().mean
        tok_s = metrics.get_throughput().mean
        n_tok = metrics.get_num_generated_tokens()
        stats = f"\n\n*TTFT: {ttft:.0f}ms · {tok_s:.1f} tok/s · {n_tok} tokens*"
        yield response + stats
```

After each response, we display performance metrics — time to first token, throughput, and total tokens — so you can see how the model performs on your hardware. Clearing the chat resets the `ChatHistory` via a `clear_chat()` callback wired to Gradio's clear button.

#### `ChatInterface` setup

{{< imagecard image="gradio_vlm.gif" size="90%" border="false" >}}
{{< /imagecard >}}

For the chat interface we use Gradio's UI out of the box, we also introduced a generation settings picker to control the generation quality.

```python
demo = gr.ChatInterface(
    fn=respond,
    multimodal=True,
    title="Qwen2-VL Chat (OpenVINO)",
    description="Multimodal chatbot powered by Qwen2-VL-2B-Instruct with OpenVINO.",
    chatbot=gr.Chatbot(height=700),
    textbox=gr.MultimodalTextbox(
        file_types=["image"], file_count="single",
        placeholder="Type a message or upload an image...",
    ),
    additional_inputs=[
        gr.Slider(0.0, 2.0, value=0.0, step=0.1, label="Temperature",
                  info="0 = greedy / deterministic"),
        gr.Slider(64, 2048, value=512, step=64, label="Max Tokens"),
        gr.Slider(0.0, 1.0, value=1.0, step=0.05, label="Top-P"),
        gr.Radio(choices=list(IMAGE_QUALITY_MAP.keys()),
                 value="Medium (448px)", label="Image Quality",
                 info="Max resolution sent to model"),
    ],
    additional_inputs_accordion=gr.Accordion("Generation Settings", open=False),
)

```
{{< imagecard image="gradio_settings.png" header="" >}}
{{< /imagecard >}}

### Hosting the Gradio server

There are two ways to run the Gradio UI:

#### **Local**
To run the app module directly use `uv` or `python`

```bash
uv run llm-chat
```
or
```bash
python -m app.gradio_app
```

#### **Docker**
The `Dockerfile` uses `python:3.12-slim` as its base image, installs [`uv`](https://github.com/astral-sh/uv) for fast dependency resolution, copies `pyproject.toml` and `uv.lock` to install the pinned environment, then copies in the `app/` and `notebooks/` directories. The `app` service in `docker-compose.yml` builds this image and starts the Gradio server automatically:

```yaml
  app:
    build: .
    network_mode: host
    volumes:
      - ./models:/app/models:ro
    environment:
      - MODE=gradio
    depends_on:
      - model-server
    restart: unless-stopped
```

It uses `network_mode: host` so the container shares the host's network stack, making Gradio available at `http://localhost:7860`. The model directory is mounted read-only. In the default Gradio mode, the entrypoint also starts Jupyter Lab in the background on port 8888, so you get notebook access alongside the chat UI.

#### entrypoint.sh

The Docker image launches both servers, Gradio and Jupyter simultaneously. Jupyter runs in the background and Gradio runs in the foreground.

```bash
#!/bin/bash
set -e

if [ "$MODE" = "jupyter" ]; then
    exec jupyter lab \
        --ip=0.0.0.0 --port=8888 \
        --no-browser --allow-root \
        --NotebookApp.token='' \
        --notebook-dir=/app/notebooks
else
    # Start Jupyter in the background for notebook access
    jupyter lab \
        --ip=0.0.0.0 --port=8888 \
        --no-browser --allow-root \
        --NotebookApp.token='' \
        --notebook-dir=/app/notebooks &

    # Start Gradio in the foreground
    exec python -m app.gradio_app "$@"
fi

```

## Deploying OpenVINO model server (OVMS) using Docker

With our local setup working, next we'll explore hosting our models as a service using OVMS. OVMS provides an OpenAI-compatible REST API out of the box — `POST /v3/chat/completions` which means you can use it with a host of clients, i.e. any client that speaks the OpenAI protocol can connect: Open WebUI, the iOS app, `curl`.

### Exporting OVMS model

OVMS is capable of pulling OpenVINO models and hosting them easily. But this assumes that the model you need is available in HuggingFace or other repository. In our case, the official OpenVINO repository doesn't include our model. 

There is a handy script in the OpenVINO repository that lets you start with the OpenVINO-optimized model and organize it in a specific model directory layout OVMS expects. Our script `export_ovms_model.sh` does that automatically.

```bash
# Clone the repository to access the helper script export_model.py
git clone https://github.com/openvinotoolkit/model_server

# Create ovms model directory
mkdir -p models-ovms

# Run helper script with a temporary isolated python env
uv run --isolated --no-project --python 3.12 \
    --pre \
    --extra-index-url https://download.pytorch.org/whl/cpu \
    --with-requirements model_server/demos/common/export_models/requirements.txt \
    model_server/demos/common/export_models/export_model.py text_generation \
    --source_model Qwen/Qwen2-VL-2B-Instruct \
    --weight-format int4 \
    --config_file_path models-ovms/config_all.json \
    --model_repository_path models-ovms

# Change ownership of the model directory to container user UID 5000
sudo chown -R 5000:5000 models-ovms

# Delete the repository we cloned for the helper script export_model.py
rm -rf model_server
```

### Docker compose configuration
With the model ready, we can use this Docker Compose specification:

```yaml
services:
  model-server:
    image: openvino/model_server:weekly
    ports:
      - "8000:8000"
    volumes:
      - ./models-ovms:/models:rw
    command: >
      --rest_port 8000
      --config_path /models/config_all.json
    restart: unless-stopped
```

To start using the service run

```bash
docker compose up
```

### Testing the API with curl

Before building client integrations, we tested the OVMS API with `curl` 

```bash
curl -X POST http://localhost:8000/v3/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "Qwen/Qwen2-VL-2B-Instruct",
    "messages": [{"role": "user", "content": "What is OpenVINO?"}],
    "max_tokens": 200
  }'

```
Output:
```json
{
  "choices": [
    {
      "finish_reason": "stop",
      "index": 0,
      "logprobs": null,
      "message": {
        "content": "OpenVINO is a software framework that allows developers to build machine learning models using the TensorFlow and PyTorch APIs. It provides a common interface for different programming languages and platforms, making it easier to integrate machine learning models into existing applications.",
        "role": "assistant",
        "tool_calls": []
      }
    }
  ],
  "created": 1771917514,
  "model": "Qwen/Qwen2-VL-2B-Instruct",
  "object": "chat.completion",
  "usage": {
    "prompt_tokens": 25,
    "completion_tokens": 49,
    "total_tokens": 74
  }
}
```

## Open WebUI client

Open WebUI is a ChatGPT-like frontend that can front model servers hosting LLMs. Since OVMS already exposes Open AI compatible `/v3/chat/completions`, Open WebUI connects to it with zero custom code. Our `docker-compose.yml` includes OVMS and Open WebUI services together making it easy for Open WebUI to discover the available models in OVMS automatically.

Here's the Open WebUI section from `docker-compose.yml`:

```yaml
  open-webui:
    image: ghcr.io/open-webui/open-webui:main
    ports:
      - "3000:8080"
    environment:
      - OPENAI_API_BASE_URL=http://model-server:8000/v3
      - OPENAI_API_KEY=not-needed
      - WEBUI_AUTH=false
      - FILE_IMAGE_COMPRESSION_WIDTH=336
      - FILE_IMAGE_COMPRESSION_HEIGHT=336
      - ENABLE_RAG=False
      - HF_HUB_OFFLINE=1
    depends_on:
      - model-server
    restart: unless-stopped
```

A few things to note:

- `OPENAI_API_BASE_URL=http://model-server:8000/v3` — this uses Docker's internal service discovery to route requests to OVMS.
- `HF_HUB_OFFLINE=1` — prevents Open WebUI from making any internet calls at startup.
- `FILE_IMAGE_COMPRESSION_WIDTH/HEIGHT=336` — we ask Open WebUI to preprocess images, and it compresses uploaded images to 336px on the client side before sending them to the API, which keeps prefill times fast.

After running `docker compose up`, Open WebUI is accessible at `http://localhost:3000`. Our model will already be selected as the default and is ready to run!

## Building an iOS VLM chatbot client with OVMS backend
This is the benefit of hosting the model as an OVMS micro service. Because OVMS exposes an OpenAI-compatible API, the iOS client can use the [OpenAI Swift SDK](https://github.com/MacPaw/OpenAI) to send requests to OVMS hosted models.

### Client configuration

```swift
private let client = OpenAI(
    configuration: .init(
        token: nil,
        host: "localhost",
        port: 8000,
        scheme: "http",
        basePath: "/v3",
        parsingOptions: .relaxed
    )
)

```

### Client-side image preprocessing

We perform client-side image processing here as well. The iOS app has its own `ImageQualityOption` enum with the same small/medium/large tiers (336, 448, 672 px) as the Python `IMAGE_QUALITY_MAP`, so both clients use the same preprocessing strategy. Here's the Swift translation of the resize logic:

```swift
extension UIImage {
    func preprocessedJPEG(maxDimension: CGFloat, compressionQuality: CGFloat) -> Data? {
        let maxSide = max(size.width, size.height)
        guard maxSide > 0 else { return nil }

        let scale = min(1, maxDimension / maxSide)
        let targetWidth = max(28, (Int(size.width * scale) / 28) * 28)
        let targetHeight = max(28, (Int(size.height * scale) / 28) * 28)
        let newSize = CGSize(width: targetWidth, height: targetHeight)

        let format = UIGraphicsImageRendererFormat.default()
        format.scale = 1
        let renderer = UIGraphicsImageRenderer(size: newSize, format: format)
        let resized = renderer.image { _ in
            draw(in: CGRect(origin: .zero, size: newSize))
        }
        return resized.jpegData(compressionQuality: compressionQuality)
    }
}

```

### Streaming responses

The OpenAI Swift SDK provides `AsyncThrowingStream` for streaming, it's an Async iterator and we can await each token and stream it to the view:

```swift
private func fetchResponse(intoMessageAt index: Int) async throws {
    let query = buildQuery()
    let stream: AsyncThrowingStream<ChatStreamResult, Error> = client.chatsStream(query: query)
    for try await result in stream {
        if let delta = result.choices.first?.delta.content {
            messages[index].text += delta
        }
    }
}

```

## Wrapping up

Here's what I built:

1. **Model preparation notebook** (`notebooks/model_preparation.ipynb`) — download Qwen2-VL-2B-Instruct, export to OpenVINO FP16, quantize to INT4, and smoke-test inference.
2. **Inference engine** (`app/model_engine.py`) — image preprocessing, VLMPipeline wrapper with ChatHistory API, and thread-based streaming via a callback queue.
3. **Gradio web UI** (`app/gradio_app.py`) — standalone multimodal chat interface with adjustable generation settings.
4. **Jupyter notebook demo** (`notebooks/gradio_demo.ipynb`) — embedded Gradio chat for interactive experimentation.
5. **Docker Compose stack** (`docker-compose.yml`) — OVMS model server plus the containerized Gradio/Jupyter app, one command to start everything.
6. **Open WebUI integration** — zero-code ChatGPT-like frontend connected to OVMS via the OpenAI-compatible API.
7. **Native iOS client** — SwiftUI app using the OpenAI Swift SDK against the OVMS backend.

### Developer friction log

Here are the rough edges I ran into while building this:

- **Documentation Fragmentation:** I found OpenVINO's documentation split across two separate sites ([openvino.ai](https://docs.openvino.ai) and [openvinotoolkit.github.io](https://openvinotoolkit.github.io/openvino.genai)), with overlapping but inconsistent versions and guidance.
- **Pre-Release Dependency:** I discovered that `ChatHistory` support for `VLMPipeline` only exists in pre-release builds of `openvino-genai`. The stable docs didn't surface this gap clearly, so pinning the right nightly version took trial and error.
- **Model Selection Constraints:** I couldn't run just any HuggingFace VLM through `VLMPipeline`, but worked via Optimum. `VLMPipeline` only supports a specific set of architectures. I had to cross-reference the supported list to land on Qwen2-VL-2B-Instruct.
- **OVMS Model Export:** I had to clone the full `model_server` repository just to access a helper script buried in the demos directory. There's no standalone CLI or documented export path for custom models.
- **Client-Side Preprocessing Trade-off:** I had to duplicate the 28-pixel image resize logic across Python, Swift, and Open WebUI config. OVMS's DAG pipeline can handle server-side preprocessing, but I found it needlessly complicated.
